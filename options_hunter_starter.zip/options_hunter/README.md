# Options Hunter — prototype

Two independent $100 paper accounts: Aggressive and Balanced.

## Run

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed by Streamlit in a browser. On an iPhone, the app requires hosting or a computer running Streamlit on an accessible network.

## Important limits

This prototype uses **synthetic** option outcomes, not real stock or option market data. Each click simulates a cycle and automatically chooses a fictional trade and settlement. It does not run continuously, connect to Robinhood, execute real orders, or demonstrate a profitable strategy. Account state lasts only for the active Streamlit session. No financial performance conclusions should be drawn from its results.
